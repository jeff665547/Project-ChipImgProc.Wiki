var searchData=
[
  ['v_5fresult_0',['v_result',['../structchipimgproc_1_1margin_1_1_param.html#aff2e015898195dcbf7a1d4376f3e1eef',1,'chipimgproc::margin::Param']]]
];
