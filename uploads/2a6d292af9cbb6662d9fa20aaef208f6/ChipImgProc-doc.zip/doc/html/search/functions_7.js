var searchData=
[
  ['identify_0',['identify',['../classchipimgproc_1_1aruco_1_1_dictionary.html#ad6d79c7a5cdfa1f77215ec5a7e8f3feb',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, Irange &amp;&amp;candidates, const std::int32_t maxcor_bits=-1) const'],['../classchipimgproc_1_1aruco_1_1_dictionary.html#aab1cac0969d06f9fee1cef5447e021dc',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, std::int32_t &amp;index, const std::vector&lt; std::int32_t &gt; &amp;candidates, const std::int32_t maxcor_bits=-1) const'],['../classchipimgproc_1_1aruco_1_1_dictionary.html#a66a5b8dfa632fd32b6b7bf14f9d060a1',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, std::int32_t &amp;index, const std::int32_t maxcor_bits=-1) const']]],
  ['infer_5fmarker_5fregions_1',['infer_marker_regions',['../structchipimgproc_1_1marker_1_1detection_1_1_reg_mat_no_rot.html#aa3b4fe6791bb485762127357d493511c',1,'chipimgproc::marker::detection::RegMatNoRot']]],
  ['info_2',['info',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#ab14197e985ede13f2e0c0d16add51a87',1,'chipimgproc::marker::detection::MKRegion']]],
  ['iterationcali_3',['IterationCali',['../structchipimgproc_1_1rotation_1_1_iteration_cali.html#a14d2e2ae823264ad8ba4340c450142b6',1,'chipimgproc::rotation::IterationCali']]]
];
