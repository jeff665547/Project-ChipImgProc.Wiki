var searchData=
[
  ['dictionary_2ehpp_0',['dictionary.hpp',['../dictionary_8hpp.html',1,'']]]
];
