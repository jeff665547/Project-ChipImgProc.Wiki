var searchData=
[
  ['feature_5fcols_0',['feature_cols',['../structchipimgproc_1_1gridding_1_1_result.html#a56d40cf27294881b88a0542efcf86ebb',1,'chipimgproc::gridding::Result']]],
  ['feature_5frows_1',['feature_rows',['../structchipimgproc_1_1gridding_1_1_result.html#aac3887dd8ec17bca0c8b14aa23e514ae',1,'chipimgproc::gridding::Result']]]
];
