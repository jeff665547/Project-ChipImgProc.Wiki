var searchData=
[
  ['bright_2dfield_20marker_20detection_0',['Bright-Field Marker Detection',['../md_doc_modules_bright_field_marker_detection.html',1,'']]]
];
