var searchData=
[
  ['img_5fidx_0',['img_idx',['../structchipimgproc_1_1_idx_rect.html#ae0a9e0b3979ad76a1cb71957dde52e1e',1,'chipimgproc::IdxRect']]]
];
