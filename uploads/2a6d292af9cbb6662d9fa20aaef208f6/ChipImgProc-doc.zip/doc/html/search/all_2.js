var searchData=
[
  ['calibrate_0',['Calibrate',['../structchipimgproc_1_1rotation_1_1_calibrate.html',1,'chipimgproc::rotation']]],
  ['calibrate_2ehpp_1',['calibrate.hpp',['../calibrate_8hpp.html',1,'']]],
  ['candi_5fmks_5fcl_2',['candi_mks_cl',['../structchipimgproc_1_1marker_1_1_des.html#a9d35518d5d2fed0b69641d1fd60701f5',1,'chipimgproc::marker::Des']]],
  ['candi_5fmks_5fcl_5fmask_3',['candi_mks_cl_mask',['../structchipimgproc_1_1marker_1_1_des.html#a0a308a77b4707fcedfc0a38af7179198',1,'chipimgproc::marker::Des']]],
  ['candi_5fmks_5fpx_4',['candi_mks_px',['../structchipimgproc_1_1marker_1_1_des.html#a9be9d65a5e53de96d040c0d587ab4251',1,'chipimgproc::marker::Des']]],
  ['candi_5fmks_5fpx_5fmask_5',['candi_mks_px_mask',['../structchipimgproc_1_1marker_1_1_des.html#a1da847dfeb73684f6a770cd295bc7700',1,'chipimgproc::marker::Des']]],
  ['cell_6',['Cell',['../structchipimgproc_1_1stat_1_1_cell.html',1,'chipimgproc::stat']]],
  ['cell_2ehpp_7',['cell.hpp',['../cell_8hpp.html',1,'']]],
  ['cell_3c_20float_20_3e_8',['Cell&lt; float &gt;',['../structchipimgproc_1_1stat_1_1_cell.html',1,'chipimgproc::stat']]],
  ['cell_5fis_5fmarker_9',['cell_is_marker',['../structchipimgproc_1_1_multi_tiled_mat.html#ac719f131f3710b821374dede8d6d03ca',1,'chipimgproc::MultiTiledMat']]],
  ['cell_5flevel_5fstitch_5fpoint_10',['cell_level_stitch_point',['../structchipimgproc_1_1_multi_tiled_mat.html#af67d51bbb60ad217cefbe49397545867',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y) const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a5d44b367f09f78cd19b7a17374a7452a',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y)']]],
  ['cell_5flevel_5fstitch_5fpoints_11',['cell_level_stitch_points',['../structchipimgproc_1_1_multi_tiled_mat.html#a39f6e55327a2ece6d5ea9c99c6a05d10',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points() const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a7ad4f6efaad7707f63b9f5bb2c837deb',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points()']]],
  ['cellinfos_12',['CellInfos',['../structchipimgproc_1_1_multi_tiled_mat.html#ad22fcb4ca080e383f99ce79e0701b65b',1,'chipimgproc::MultiTiledMat']]],
  ['clean_5fborder_13',['clean_border',['../structchipimgproc_1_1_grid_raw_img.html#a3b2733e40d33675e36f9114b1ca8401a',1,'chipimgproc::GridRawImg']]],
  ['clone_14',['clone',['../structchipimgproc_1_1_grid_raw_img.html#a4b0295f2dee46dd620e71970b4cc0163',1,'chipimgproc::GridRawImg']]],
  ['coding_5fbits_15',['coding_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a36a85b17018178063bb0943c1c4b777f',1,'chipimgproc::aruco::Dictionary']]],
  ['cols_16',['cols',['../structchipimgproc_1_1_grid_raw_img.html#a752782631cd6719feb8fcf07fb779a83',1,'chipimgproc::GridRawImg::cols()'],['../structchipimgproc_1_1_multi_tiled_mat.html#a7c9cb316b427469d96b551804cbcdec1',1,'chipimgproc::MultiTiledMat::cols()']]],
  ['compute_5fmaxcor_5fbits_17',['compute_maxcor_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a19cd512afa4eca13bcb544241d202c7b',1,'chipimgproc::aruco::Dictionary']]],
  ['const_2eh_18',['const.h',['../const_8h.html',1,'']]],
  ['cv_19',['cv',['../structchipimgproc_1_1stat_1_1_mats.html#a017c6117e50d5f3d3e880ed80ac9bd5d',1,'chipimgproc::stat::Mats::cv()'],['../structchipimgproc_1_1stat_1_1_cell.html#a6da095615ddff0eefa817e5de90e2075',1,'chipimgproc::stat::Cell::cv()']]]
];
