var searchData=
[
  ['num_0',['num',['../structchipimgproc_1_1stat_1_1_mats.html#a4e1c69525e32174bfdf40b5510e0dd3a',1,'chipimgproc::stat::Mats::num()'],['../structchipimgproc_1_1stat_1_1_cell.html#aa4995059a24e168eafa20af1ebf7bbb3',1,'chipimgproc::stat::Cell::num()']]]
];
