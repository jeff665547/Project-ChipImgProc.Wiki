var searchData=
[
  ['y_5fi_0',['y_i',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#ad16878c6f778fcd64412fb549f5f87a7',1,'chipimgproc::marker::detection::MKRegion']]]
];
