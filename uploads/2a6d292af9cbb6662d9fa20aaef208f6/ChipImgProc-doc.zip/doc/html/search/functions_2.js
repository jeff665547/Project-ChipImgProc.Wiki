var searchData=
[
  ['cell_5fis_5fmarker_0',['cell_is_marker',['../structchipimgproc_1_1_multi_tiled_mat.html#ac719f131f3710b821374dede8d6d03ca',1,'chipimgproc::MultiTiledMat']]],
  ['cell_5flevel_5fstitch_5fpoint_1',['cell_level_stitch_point',['../structchipimgproc_1_1_multi_tiled_mat.html#af67d51bbb60ad217cefbe49397545867',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y) const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a5d44b367f09f78cd19b7a17374a7452a',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y)']]],
  ['cell_5flevel_5fstitch_5fpoints_2',['cell_level_stitch_points',['../structchipimgproc_1_1_multi_tiled_mat.html#a39f6e55327a2ece6d5ea9c99c6a05d10',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points() const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a7ad4f6efaad7707f63b9f5bb2c837deb',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points()']]],
  ['clean_5fborder_3',['clean_border',['../structchipimgproc_1_1_grid_raw_img.html#a3b2733e40d33675e36f9114b1ca8401a',1,'chipimgproc::GridRawImg']]],
  ['clone_4',['clone',['../structchipimgproc_1_1_grid_raw_img.html#a4b0295f2dee46dd620e71970b4cc0163',1,'chipimgproc::GridRawImg']]],
  ['coding_5fbits_5',['coding_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a36a85b17018178063bb0943c1c4b777f',1,'chipimgproc::aruco::Dictionary']]],
  ['cols_6',['cols',['../structchipimgproc_1_1_grid_raw_img.html#a752782631cd6719feb8fcf07fb779a83',1,'chipimgproc::GridRawImg::cols()'],['../structchipimgproc_1_1_multi_tiled_mat.html#a7c9cb316b427469d96b551804cbcdec1',1,'chipimgproc::MultiTiledMat::cols()']]],
  ['compute_5fmaxcor_5fbits_7',['compute_maxcor_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a19cd512afa4eca13bcb544241d202c7b',1,'chipimgproc::aruco::Dictionary']]]
];
