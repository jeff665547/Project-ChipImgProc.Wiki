var searchData=
[
  ['calibrate_0',['Calibrate',['../structchipimgproc_1_1rotation_1_1_calibrate.html',1,'chipimgproc::rotation']]],
  ['cell_1',['Cell',['../structchipimgproc_1_1stat_1_1_cell.html',1,'chipimgproc::stat']]],
  ['cell_3c_20float_20_3e_2',['Cell&lt; float &gt;',['../structchipimgproc_1_1stat_1_1_cell.html',1,'chipimgproc::stat']]]
];
