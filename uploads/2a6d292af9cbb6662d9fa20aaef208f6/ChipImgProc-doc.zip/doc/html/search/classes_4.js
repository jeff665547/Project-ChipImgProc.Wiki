var searchData=
[
  ['estimatebias_0',['EstimateBias',['../structchipimgproc_1_1marker_1_1detection_1_1_estimate_bias.html',1,'chipimgproc::marker::detection']]],
  ['estimatetransformmat_1',['EstimateTransformMat',['../structchipimgproc_1_1warped__mat_1_1_estimate_transform_mat.html',1,'chipimgproc::warped_mat']]]
];
