var searchData=
[
  ['identify_0',['identify',['../classchipimgproc_1_1aruco_1_1_dictionary.html#ad6d79c7a5cdfa1f77215ec5a7e8f3feb',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, Irange &amp;&amp;candidates, const std::int32_t maxcor_bits=-1) const'],['../classchipimgproc_1_1aruco_1_1_dictionary.html#aab1cac0969d06f9fee1cef5447e021dc',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, std::int32_t &amp;index, const std::vector&lt; std::int32_t &gt; &amp;candidates, const std::int32_t maxcor_bits=-1) const'],['../classchipimgproc_1_1aruco_1_1_dictionary.html#a66a5b8dfa632fd32b6b7bf14f9d060a1',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, std::int32_t &amp;index, const std::int32_t maxcor_bits=-1) const']]],
  ['idxrect_1',['IdxRect',['../structchipimgproc_1_1_idx_rect.html',1,'chipimgproc']]],
  ['image_20gridding_2',['Image Gridding',['../md_doc_modules_image_gridding.html',1,'']]],
  ['image_20rotation_20angle_20estimation_20and_20calibration_3',['Image Rotation Angle Estimation and Calibration',['../md_doc_modules_image_rotation_angle_estimation_and_calibration.html',1,'']]],
  ['image_20stitching_4',['Image Stitching',['../md_doc_modules_image_stitching.html',1,'']]],
  ['img_5fidx_5',['img_idx',['../structchipimgproc_1_1_idx_rect.html#ae0a9e0b3979ad76a1cb71957dde52e1e',1,'chipimgproc::IdxRect']]],
  ['indextype_6',['IndexType',['../structchipimgproc_1_1_multi_tiled_mat.html#a98139a753a9ded69806b648501a65983',1,'chipimgproc::MultiTiledMat']]],
  ['indexvalue_7',['IndexValue',['../structchipimgproc_1_1_multi_tiled_mat.html#a1d58c3da8cd8457adea99bb23f92aa3f',1,'chipimgproc::MultiTiledMat']]],
  ['indexwrapper_8',['IndexWrapper',['../structchipimgproc_1_1detail_1_1_index_wrapper.html',1,'chipimgproc::detail']]],
  ['indexwrapper_3c_20std_3a_3auint16_5ft_20_3e_9',['IndexWrapper&lt; std::uint16_t &gt;',['../structchipimgproc_1_1detail_1_1_index_wrapper.html',1,'chipimgproc::detail']]],
  ['infer_5fmarker_5fregions_10',['infer_marker_regions',['../structchipimgproc_1_1marker_1_1detection_1_1_reg_mat_no_rot.html#aa3b4fe6791bb485762127357d493511c',1,'chipimgproc::marker::detection::RegMatNoRot']]],
  ['info_11',['info',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#ab14197e985ede13f2e0c0d16add51a87',1,'chipimgproc::marker::detection::MKRegion']]],
  ['installation_12',['Installation',['../md_doc_modules_installation.html',1,'']]],
  ['introduction_13',['Introduction',['../md_doc_modules_introduction.html',1,'']]],
  ['iteration_5fcali_2ehpp_14',['iteration_cali.hpp',['../iteration__cali_8hpp.html',1,'']]],
  ['iterationcali_15',['IterationCali',['../structchipimgproc_1_1rotation_1_1_iteration_cali.html',1,'chipimgproc::rotation::IterationCali&lt; Float, RotEst, RotCali &gt;'],['../structchipimgproc_1_1rotation_1_1_iteration_cali.html#a14d2e2ae823264ad8ba4340c450142b6',1,'chipimgproc::rotation::IterationCali::IterationCali()']]]
];
