var searchData=
[
  ['param_0',['Param',['../structchipimgproc_1_1margin_1_1_param.html',1,'chipimgproc::margin']]],
  ['param_2ehpp_1',['param.hpp',['../param_8hpp.html',1,'']]],
  ['pat_5fnum_2',['pat_num',['../structchipimgproc_1_1marker_1_1_layout.html#a48c516c0bfc2d081572ba2aa9981f9e9',1,'chipimgproc::marker::Layout']]],
  ['patternnum_3',['PatternNum',['../structchipimgproc_1_1marker_1_1_layout.html#a8e0888dc7c50bdea82a96d0afc6ca963',1,'chipimgproc::marker::Layout']]],
  ['probe_20intensity_20extraction_4',['Probe Intensity Extraction',['../md_doc_modules_probe_intensity_extraction.html',1,'']]],
  ['pseudo_5',['Pseudo',['../structchipimgproc_1_1gridding_1_1_pseudo.html',1,'chipimgproc::gridding']]],
  ['pseudo_2ehpp_6',['pseudo.hpp',['../pseudo_8hpp.html',1,'']]]
];
