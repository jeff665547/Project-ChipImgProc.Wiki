var searchData=
[
  ['group_0',['Group',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#ad2cad30eff41f5f286e82c55c11e72ff',1,'chipimgproc::marker::detection::MKRegion']]]
];
