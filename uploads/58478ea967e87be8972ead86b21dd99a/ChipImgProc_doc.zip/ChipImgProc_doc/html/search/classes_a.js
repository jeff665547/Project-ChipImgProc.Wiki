var searchData=
[
  ['originpos_0',['OriginPos',['../structchipimgproc_1_1_origin_pos.html',1,'chipimgproc']]]
];
